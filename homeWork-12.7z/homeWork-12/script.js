const clearBtn = document.querySelector(".clearBtn");
const createBtn = document.querySelector(".createBtn");
const userFormList = document.querySelector(".userFormList");

const nameInput = document.querySelector("#name");
const surnameInput = document.querySelector("#surname");
const ageInput = document.querySelector("#age");


// Если пользователю меньше 18 лет дизейблит кнопку
    ageInput.addEventListener('input', () => {
        createBtn.disabled = ageInput.value < 18;
    });

    // На кнопку "создать" вешеем событие 
    createBtn.addEventListener('click', () => {


        // Cоздадим пустой объект {}, присвоим значения полей input
        const itemObj = {};
        itemObj.name = nameInput.value;
        itemObj.surname = surnameInput.value;
        itemObj.age = ageInput.value;
                // Значения полей input
        const name = nameInput.value;
        const surname = surnameInput.value;
        const age = ageInput.value;
        // Генератор id из лекции
        itemObj.id = Math.floor(Math.random() * 100)
        // Пушим в массив 'listArr' ==> 'itemObj'
        listArr.push(itemObj);
        console.log(listArr);

        // Создаем элемент списка пользователя 
        const user = document.createElement('li');
        user.innerText = `Пользователь: ${name} ${surname}, ${age} лет`;
        // Добавляем элемент списка
        userFormList.append(user);
        listArr.push(user)
        console.log(user);
        
        // Отчистка input
        nameInput.value = '';
        ageInput.value = '';
        surname.value = '';

        // Local Storage
        localStorage.setItem('list', JSON.stringify(listArr));
    });

    // Чистим local storage
    clearBtn.addEventListener('click', () => {
        localStorage.clear();
    });

    // Создаем массив
    let listArr = [];
    
    if (localStorage.getItem('list')) {
        listArr = JSON.parse(localStorage.getItem('list'));

        listArr.forEach((user) => {
            const el = document.createElement('li');
            el.innerText = user.value;
            userFormList.append(el);
            userFormList.getElementsByClassName('li')
            console.log(listArr);
        });
    };

		// window.onload = function() {
		// 	// Получаем сохраненных пользователей из локального хранилища
		// 	const users = JSON.parse(localStorage.getItem('list')) || [];

		// 	// Добавляем каждого пользователя в список
		// 	users.forEach(function(user) {
		// 		const userItem = document.createElement('li');
		// 		userItem.textContent = user;
		// 		userList.appendChild(userItem);
		// 	});
		// };